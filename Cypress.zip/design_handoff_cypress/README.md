# Handoff: Cypress — an app for attending to the urban forest

## Overview
Cypress is a concept sketch for a mobile-first app for caring for street trees: learning about them, tracking them across seasons, sharing them, and organizing volunteer care. Trees sit at the center; the app also crowd-sources and open-sources tree data and coordinates volunteer workdays. This bundle contains the full design exploration as four linked HTML prototypes plus a landing/essay page.

This is a **non-commercial concept sketch**, not a product pitch. There is no monetization, no "growth" framing. Keep that spirit in any implementation: plain, human copy; no product-marketing vocabulary.

## About the Design Files
The files in this bundle are **design references authored in HTML** — prototypes that show the intended look, copy, and behavior. They are **not production code to copy directly**. They are built as "Design Components" (a small custom `<x-dc>` runtime with inline styles and a `renderVals()` logic class); that runtime is specific to the design tool and should **not** be carried into a real codebase.

Your task is to **recreate these designs in the target codebase's environment** (React, React Native, SwiftUI, etc.) using its established components, patterns, and libraries. If no codebase exists yet, choose an appropriate stack — given the heavy mobile focus, React Native / Expo or SwiftUI for the app, plus a plain server-rendered web page for the public tree page, would all be reasonable.

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and interactions are final-intent. Recreate the UI faithfully using the codebase's own primitives — match the hex values, type ramp, and radii below rather than approximating. The one deliberately rough element is imagery: every tree photo is a CSS gradient placeholder standing in for a real photo (see Assets).

## Product concept — four ideas
The landing page ("The idea") frames the whole thing around four principles. Keep these legible in the build:
1. **Trees at the center.** Every profile belongs to a tree; all activity accumulates there (photos over years, a season foliage strip, measurements, notes). If the city removes a tree, its page becomes a read-only memorial; a replanted site links back.
2. **Getting to know a tree, one visit at a time.** A visit = a photo lined up against a ghost of the last one, plus an optional note, in ~10 seconds. No points, streaks, or leaderboards.
3. **Neighbors find each other through trees.** Every tree has a public page that opens with no app or account. Sharing recruits regulars; groups run workdays from the app.
4. **Data standardized and decentralized.** Every number carries its method (e.g. DBH "taped" vs "est."); vitality on an anchored 5-point scale. Everything exportable under ODbL; city inventories sync both ways; no single owner.

## Design tokens

### Color
| Role | Hex | Notes |
|------|-----|-------|
| App background (parchment) | `#EBE8DC` | page background |
| Surface / screen background (light) | `#F5F6EF` | most mobile screens |
| Card white | `#FFFFFF` | cards, sheets |
| Warm panel | `#F7F5EC` | quote panel, callout cards |
| Panel border | `#DDD9C9` / `#E3E8D9` | card borders (warm / cool) |
| Hairline | `#D8D4C4` | section dividers |
| Ink (primary text) | `#1C2A21` | body/heading text |
| Body green-gray | `#3C4A3E` | paragraph text |
| Muted text | `#66735F` | secondary text |
| Faint mono/label | `#8B9482` / `#77836F` | micro-labels, timestamps |
| Forest (deep) | `#1D4634` | primary buttons, dark header, active |
| Forest (mid / link) | `#2F6B4F` | links, accents, focus borders |
| Link hover | `#1D4634` | |
| Leaf green (mint fill) | `#E2EFE2` | "thriving" chips, badges (text `#28623F`) |
| Callout green bg | `#EFF3E3` (border `#DFE6CD`, text `#41522F`) | "why this exists" notes |
| Amber (needs care / warning) | `#B4711F`, text `#8A5A17`/`#8A6A2A` | care flags, "est." badge, review flags |
| Amber panel | `#F8EFDF` (border `#EBD3A8`) | warning banners |
| Amber card border | `#D9A05B` | coordinator "needs your eyes" |
| GPS blue (user location) | `#3577C9` | location dot |
| Foliage strip greens | `#5D9159`, `#8FB573`, `#BCD3A8` | 12-month season strip |
| Dark mode bg | `#141E16` / `#10160F` / `#0E1712` | dark map / camera / dark surfaces |
| Dark mode text | `#E4EBE2` | |

### Typography
Three families, loaded from Google Fonts:
- **Source Serif 4** (`ital,opsz,wght` 400–700) — display & headings. Used for H1 (42px), section H2 (29–30px), tree names (17–27px), card titles. Weight 600. Also italic for species Latin names and the epigraph.
- **Alegreya Sans** (400/500/700/800, plus italic 400) — body / UI. Body text 15–17px, line-height ~1.65. This is the default `body` font.
- **Spline Sans Mono** (400–600) — micro-labels, timestamps, coordinates, data values, breadcrumbs. Typically 10–13px, `letter-spacing: .1–.18em`, often `text-transform: uppercase`.

Type ramp seen in use: H1 42px/1.14; H2 29–30px; screen titles 20–27px; body 15–17px/1.65; card body 13–14px; micro-label 10–11px.

### Copy rules (important — carry into the build)
- **No spaces around em dashes.** Write `trees—memorials`, never `trees — memorials`.
- Voice is plain and human. Avoid "X, not Y" constructions, semicolon aphorisms, parallel triads, punchy fragments, and startup vocabulary.
- Micro-labels are uppercase mono with letter-spacing; prose is sentence case.
- Dates styled like "Summer 2026".
- No product/monetization language anywhere.

### Radius & shadow
- Radii: pills `999px`; cards `14–18px`; large sheets `26px 26px 0 0`; small chips/thumbs `10–14px`; device screen `48px` (bezel).
- Shadows are soft and green-tinted, e.g. `0 1px 3px rgba(25,40,28,.05)` (resting card), `0 6px 20px rgba(47,107,79,.16)` (raised/selected), `0 8px 24px rgba(20,50,30,.4)` (floating button), `0 -12px 40px rgba(10,20,14,.32)` (bottom sheet).

### Spacing
Screens use an 8px-ish rhythm: gaps of 8/10/14/16px between cards, section padding 24–26px on desktop panels, 16–20px on mobile screens, section vertical rhythm 56–88px on the landing/spec pages.

## Screens / Views

### A. Landing / essay page ("The idea")  — `Cypress Story.dc.html`
- **Purpose:** explain the concept and route to the three interactive pieces.
- **Layout:** single centered column, `max-width: 640px`, generous vertical rhythm. Mono eyebrow → epigraph (Mary Oliver quote, four style variants: plain / left-rule / panel / display — default is the left-rule) → H1 → two intro paragraphs → four numbered principle sections (each: mono number, H2, paragraph, and a small illustrative widget) → "How to read this sketch" with three link cards → footer line.
- **Notable widgets:** a 12-cell foliage season strip; visit/care log rows; public-URL pills; method-tagged data pills (`DBH 64 cm · taped`, `18 m · est.`, `vitality 4 · anchored scale`, `ODbL · CSV / GeoJSON`).
- **Tweakable prop:** `epigraphStyle` enum (`plain`/`rule`/`panel`/`display`).

### B. Screen spec — `Cypress Screens.dc.html`
A long scrollable spec showing 19 mobile screens + 3 dark-mode screens + 1 public web page, each in a device/browser frame, grouped into five sections with a mono eyebrow, H2, and a "Back to top" link beside each heading. Each screen has a caption explaining its reasoning.
- **Section: Six screens that carry the whole loop** (`#sec-loop`): 01 Map home, 02 What tree is this, 03 Tree profile, 04 Visit (dark camera), 05 Light check-in, 06 Report/311.
- **Section: The flows behind the first screen** (`#sec-flows`): 07 Species page, 08 Species you know, 09 Care log, 10 Share, 11 Growth history, 12 Almanac, 13 Tree activity.
- **Section: Built for day one and muddy hands** (`#sec-field`): 14 Cold-start profile, 15 Account ask, 16 Measure, 17 Outbox (offline), 18 Next tree, 19 Memorial.
- **Section: Dark mode, same forest** (`#sec-dark`): D1 Dark map, D2 Dark tree profile, D3 Dark check-in.
- **Section: Every tree gets a page worth sending** (`#sec-web`): W1 Public tree page (desktop browser).
- **Navigation:** an "On this page" nav links to the five section ids. The screen-01 caption contains an inline link to screen 19 (the memorial), `href="#screen-19"`.

### C. Clickable prototype — `Cypress Prototype.dc.html`
The playable ten-second-visit loop inside an iPhone frame. State machine over these screens:
`map → identify → profile → camera → saved → (next tree) …`, plus `grove`, and bottom-sheet overlays for `care` and `share`.
- **Map:** SF street-grid abstraction; green pins (city trees), one amber pulsing pin (needs care), a blue GPS dot, cluster count badges, search bar, filter chips (All / In bloom / Needs care), a floating "What tree is this?" button, a bottom tree card, and a 4-tab bottom bar (Map / My Grove / Journal / You). Tapping a pin or the card → profile.
- **Identify:** GPS-ranked species candidate cards ("Closest · is it this one?"), each with a gradient thumb, common + Latin name, and a "tell" (identifying feature). Top card is pre-selected.
- **Profile:** photo header (gradient), 12-cell foliage strip, name + THRIVING badge, "how to recognize it" note, primary "Visit · say hello with a photo" button, secondary actions (Favorite / Care / Share / Report), activity feed, and Height/DBH stat cards with method badges.
- **Camera (dark):** viewfinder with a 30% ghost overlay of the last photo, framing corners, shot-type chips (Full tree / Trunk / Leaf close-up), shutter, note field, phenology chips (New growth / Cones / Storm damage), "Log visit" button, and an offline "saves to outbox" line.
- **Saved:** success check, "second visitor this week" social proof, a mini route map where done trees "go quiet", and a "Next nearest" CTA advancing to the next tree. On the 3rd save, an **account-ask bottom sheet** appears (Continue with Apple/Google/email + ODbL opt-in + "Not now, keep on this phone").
- **Care sheet:** toggle chips (Watered / Mulched / Weeded basin / Litter cleared), optional photo/note, Done. Logs a "just now" care entry on the profile.
- **Share sheet:** preview card, public URL (`cypress.app/sf/tree/9f3a`), editable blurb, Copy link → "Link copied".
- **Grove:** "Three trees know you", species-known progress, your-trees list, neighborhood/steward callouts, bottom bar.
- **Breadcrumb** under the phone tracks MAP → ID → PROFILE → VISIT → SAVED with a restart.
- **Tweakable prop:** `coachmarks` boolean (shows/hides the guiding tooltips).

### D. Coordinator — `Cypress Coordinator.dc.html`
The org side, shown in a desktop browser window (`cypress.app/org/workday`, 1280×840). A live Saturday workday dashboard.
- **Left column:** workday title with LIVE badge and 10:42 AM clock, "31 of 54 trees done" progress bar (done / claimed / waiting legend), three route cards (Jae/Priya/Tom with per-route progress and last-check-in, one offline), and a live activity feed.
- **Right column:** "This week · digest preview" stat trio (128 check-ins / 64 care logs / 7 follow-ups), a "Needs your eyes" amber card (dead-tree confirmation, DBH anomaly), an "Export the weekend" card (Download CSV / GeoJSON with a method/ODbL/sync note), and a "Why this screen exists" note.

### E. Suite shell — `Cypress Suite.dc.html`
The wrapper that ties A–D together: a sticky top header (Cypress wordmark + "concept sketch" badge) with four pill tabs — **The idea / Screen spec / Clickable loop / Coordinator** — that swap the four pages below. Tab state is mirrored to the URL hash (`#story`/`#screens`/`#proto`/`#coord`); switching tabs scrolls to top. In-page `#` links (not tab targets) are handled with a delegated smooth-scroll that offsets 76px for the sticky header. This is the entry point to open.
- **Tweakable props:** `epigraphStyle` (enum, passed to Story), `headerTone` (enum `parchment`/`forest`), `coachmarks` (boolean, passed to Prototype).

## Interactions & Behavior
- **Tab / route switching (Suite):** hash-driven; each switch resets scroll to top. Replicate with the target router; keep the header offset for anchor links.
- **Prototype state machine:** the whole clickable loop is client-side state (current screen, `snapped`, note text, phenology/care chip toggles, `treeIdx` 0–2, `saves` count, `account` state `none`/`ask`/`linked`/`dismissed`). Key transitions:
  - Camera "Log visit" is disabled until a photo is "snapped".
  - After the 3rd saved visit, the account-ask sheet triggers automatically.
  - "Next nearest" advances `treeIdx`; after tree 3, the CTA routes to the grove.
- **Animations (prototype, ~cubic-bezier(.22,.9,.3,1)):** screen fade-in (`czFade`, .32s), bottom-sheet rise (`czSheet`), pin drop stagger (`czPinDrop`), amber pin pulse (`czPulse`, 2.4s loop), shutter flash (`czFlash`), success pop (`czPop`). Keep them subtle.
- **Hover/active:** cards raise slightly and shift border to `#2F6B4F`; primary buttons darken `#1D4634`→`#2F6B4F`; the shutter scales on active.
- **Offline model:** visits/care save to an "outbox" and sync when signal returns — surface this in copy, not just as a spinner.

## State Management
Client state needed for the app portion:
- Session/loop: `currentScreen`, `treeIdx`, `snapped`, `note`, `phenologyChips{}`, `careChips{}`, `visitCount`, `saves`, `account`, sheet-open flags (`careOpen`, `shareOpen`, `copied`).
- Domain data (fetched in a real build): tree records (id, species common+Latin, location, vitality, method-tagged measurements, photo timeline, season strip, visitor/care history, memorial flag + link to replanted tree), species field-guide entries, user's grove & species-known list, steward groups & workday routes, live activity feed.
- Coordinator: workday (routes, per-route progress, live feed, review flags, weekly digest counts, export/sync status).

## Assets
- **Logo:** a small Cypress mark is embedded as a base64 PNG in each file's header (search for the `<img src="data:image/png;base64,` at the top of each `.dc.html`). Extract it from any file if you need it, or replace with the real brand mark.
- **Tree photos:** all imagery is **CSS-gradient placeholders** (layered radial + linear gradients) standing in for real tree photos. Replace with real photography; keep the "best photo" + season-strip concept.
- **Icons:** drawn inline as small SVGs (search, chevrons, checkmarks, leaf-diamond glyph, map/journal/profile tab glyphs). Swap for the codebase's icon set.
- **Fonts:** Source Serif 4, Alegreya Sans, Spline Sans Mono (Google Fonts).
- **Frames:** `ios-frame.jsx` (iPhone bezel, supports a `dark` prop) and `browser-window.jsx` (desktop chrome with a URL) are presentation scaffolding only — do not ship them; use the target platform's real chrome.

## Real-world data note
Numbers referencing the real world must stay accurate: San Francisco has ~125,000 street trees (2017 census / SF DPW). Sample data inside the app (tree names, routes, counts) is fictional and illustrative.

## Files
Included in this bundle (all under `design_handoff_cypress/`):
- `Cypress Suite.dc.html` — the shell / entry point (open this first).
- `Cypress Story.dc.html` — landing/essay page.
- `Cypress Screens.dc.html` — the 19+ screen spec.
- `Cypress Prototype.dc.html` — the clickable loop.
- `Cypress Coordinator.dc.html` — the org dashboard.
- `ios-frame.jsx`, `browser-window.jsx` — presentation frames (reference only).
- `support.js` — the design-tool runtime (reference only; **do not** port).

To view the prototypes as intended, open `Cypress Suite.dc.html` in a browser (it loads the others as sub-views).
